"""Persistence of the yield response: the same plots (study, site, crop, treatment, biochar, dose)
observed at two or more times after application.

Model: lnRR_st = A_s * exp(-k * (t - t_first,s)), A_s per series profiled out; k by 1-D search,
ivw weights, bootstrap over studies. k > 0 means the effect fades; k < 0 that it grows.
Also: pairwise first-vs-last change, and the same split by soil pH.
"""
import numpy as np
import pandas as pd
from scipy.optimize import minimize_scalar
from fitlib import weights, tau2_estimate, experiments

d = pd.read_csv("/home/claude/bc/harmonised2.csv")
d = d[(d.field == 1) & d.years.notna()].copy()
key = ["src", "study", "crop", "yieldtype", "treat", "dose", "lat", "lon", "feed", "HTT", "bcC", "Nrate", "pH"]
d["series"] = d[key].astype(object).fillna("NA").astype(str).agg("|".join, axis=1)
# average replicate rows at the same time point
s = d.groupby(["series", "years"], as_index=False).agg(y=("lnRR", "mean"), v=("v", "mean"), study=("study", "first"),
                                                       src=("src", "first"), pH=("pH", "first"), dose=("dose", "first"),
                                                       CEC=("CEC", "first"))
s = s[s.groupby("series").years.transform("nunique") >= 2].reset_index(drop=True)
s["t"] = s.years - s.groupby("series").years.transform("min")
print(f"series with >=2 time points: {s.series.nunique()} from {s.study.nunique()} studies; rows {len(s)}")
print(s.groupby("src").agg(series=("series", "nunique"), studies=("study", "nunique"), max_t=("t", "max")))
tmax = s.groupby("series").t.max()
print("span of follow-up (yr):", tmax.describe().round(2).to_dict())

# experiments() expects these names
s["exp"] = s.series
tau2 = 0.012


def fit_k(df, w):
    codes, _ = pd.factorize(df.exp); y = df.y.values; t = df.t.values

    def sse(k):
        g = np.exp(-k * t)
        A = np.bincount(codes, w * y * g) / np.bincount(codes, w * g * g)
        return (w * (y - A[codes] * g) ** 2).sum()
    return minimize_scalar(sse, bounds=(-1.5, 3.0), method="bounded").x


def boot(df, n=500, seed=4):
    r = np.random.default_rng(seed); st = df.study.unique(); by = {k: g for k, g in df.groupby("study")}
    out = []
    for _ in range(n):
        pick = r.choice(st, len(st))
        b = pd.concat([by[k].assign(exp=by[k].exp + f"#{i}", study=by[k].study + f"#{i}") for i, k in enumerate(pick)], ignore_index=True)
        out.append(fit_k(b, weights(b, "ivw", tau2)))
    return np.percentile(out, [5, 50, 95])


rows = []
for lab, sub in [("All", s), ("pH>=6.5", s[s.pH >= 6.5]), ("pH<6.0", s[s.pH < 6.0]),
                 ("follow-up >=2 yr", s[s.series.isin(tmax[tmax >= 2].index)])]:
    sub = sub.reset_index(drop=True)
    if sub.study.nunique() < 4:
        continue
    k = fit_k(sub, weights(sub, "ivw", tau2)); q = boot(sub)
    # first vs last pairwise change, and share of series whose effect shrank
    fl = sub.sort_values("t").groupby("series").agg(y0=("y", "first"), y1=("y", "last"), dt=("t", "max"))
    pos = fl[fl.y0 > 0.02]
    ratio = (pos.y1 / pos.y0)
    half = np.log(2) / k if k > 0 else np.inf
    print(f"\n{lab}: series={sub.series.nunique()} studies={sub.study.nunique()}  k={k:.3f}/yr "
          f"[90% CI {q[0]:.3f}, {q[2]:.3f}]  half-life={half:.1f} yr")
    print(f"   series with initial gain >2%: n={len(pos)}, median last/first = {ratio.median():.2f} "
          f"(IQR {ratio.quantile(.25):.2f}-{ratio.quantile(.75):.2f}), median follow-up {pos.dt.median():.1f} yr, "
          f"share shrinking = {(pos.y1 < pos.y0).mean():.2f}")
    rows.append(dict(subset=lab, series=sub.series.nunique(), studies=sub.study.nunique(), k=k, k_lo=q[0], k_hi=q[2],
                     median_ratio=ratio.median(), n_pos=len(pos)))
pd.DataFrame(rows).to_csv("/home/claude/bc/persistence.csv", index=False)
s.to_csv("/home/claude/bc/persistence_series.csv", index=False)

# mean trajectory by time since first observation (series-normalised), ivw-free descriptive
s["t_bin"] = pd.cut(s.t, [-0.01, 0.01, 1.01, 2.01, 10], labels=["first", "+<=1yr", "+1-2yr", "+>2yr"])
y0 = s[s.t == 0].set_index("series").y
s["rel"] = s.y / s.series.map(y0)
print("\nmedian response relative to first observation (series with first gain >2%):")
print(s[s.series.map(y0) > 0.02].groupby("t_bin", observed=True).agg(n=("rel", "size"), studies=("study", "nunique"),
                                                                       median_rel=("rel", "median")).round(2))
