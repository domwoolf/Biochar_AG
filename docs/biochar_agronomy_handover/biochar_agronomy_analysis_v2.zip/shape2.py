"""Nonparametric within-experiment dose shape (step function, A_j per experiment) on cleaned data, ivw."""
import numpy as np
import pandas as pd
from fitlib import weights, tau2_estimate

m = pd.read_csv("/home/claude/bc/within_exp2.csv")
F = m[m.field == 1].reset_index(drop=True)
tau2 = tau2_estimate(F)
bins = [0, 2.5, 5, 10, 20, 40, 1e9]
labels = ["<=2.5", "2.5-5", "5-10", "10-20", "20-40", ">40"]
REF = 3


def step_shape(df, w, iters=300):
    b = pd.cut(df.dose, bins, labels=False).values
    codes, _ = pd.factorize(df.exp); y = df.y.values
    h = np.ones(len(labels))
    for _ in range(iters):
        g = h[b]
        A = np.bincount(codes, w * y * g) / np.bincount(codes, w * g * g)
        a = A[codes]
        num = np.bincount(b, w * y * a, minlength=len(labels)); den = np.bincount(b, w * a * a, minlength=len(labels))
        h = np.where(den > 0, num / np.where(den > 0, den, 1), 1.0)
        h = h / h[REF]
    return h, np.bincount(b, minlength=len(labels))


def boot(df, n=400, seed=2):
    r = np.random.default_rng(seed); st = df.study.unique(); by = {s: g for s, g in df.groupby("study")}
    out = []
    for _ in range(n):
        pick = r.choice(st, len(st))
        bdf = pd.concat([by[s].assign(exp=by[s].exp + f"#{i}", study=by[s].study + f"#{i}") for i, s in enumerate(pick)], ignore_index=True)
        out.append(step_shape(bdf, weights(bdf, "ivw", tau2))[0])
    return np.percentile(np.array(out), [5, 95], axis=0)


rows = []
for lab, sub in [("All field", F), ("Field pH>=6.5", F[F.pH >= 6.5]), ("Field pH<6.0", F[F.pH < 6.0])]:
    sub = sub.reset_index(drop=True)
    h, cnt = step_shape(sub, weights(sub, "ivw", tau2)); lo, hi = boot(sub)
    nst = sub.groupby(pd.cut(sub.dose, bins, labels=labels), observed=False).study.nunique()
    print(f"\n{lab}: relative response by dose bin (10-20 Mg/ha = 1)")
    for i, L in enumerate(labels):
        print(f"  {L:>6s}: h={h[i]:5.2f} [{lo[i]:5.2f},{hi[i]:5.2f}]  n={cnt[i]} studies={nst.iloc[i]}")
        rows.append(dict(subset=lab, bin=L, h=h[i], lo=lo[i], hi=hi[i], n=cnt[i], studies=nst.iloc[i]))
pd.DataFrame(rows).to_csv("/home/claude/bc/step_shape2.csv", index=False)
