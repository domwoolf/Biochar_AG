"""N2O response to biochar: within-experiment dose shape, aging, and multilevel meta-regression (Xu et al. 2021)."""
import numpy as np
import pandas as pd
from fitlib import experiments, weights, fit_sat, fit_power, fit_two, boot_studies, g_sat
import metareg

num = lambda s: pd.to_numeric(s, errors="coerce")
x = pd.read_excel("/home/claude/bc/2f8e6375-Biochar-crop_yield_SOC_GWP.xlsx", "All", header=None).iloc[2:].reset_index(drop=True)
ck, sdc, nc, t, sdt, nt = (num(x[c]) for c in [93, 94, 95, 96, 97, 98])
crop = x[23].astype(str).str.lower().str.replace(r"[^a-z ]", "", regex=True).str.strip()
treat = x[32].astype(str)
n2o = pd.DataFrame({
    "src": "XU21", "study": x[0].astype(str).str.strip() + " " + x[2].astype(str),
    "crop": crop, "yieldtype": "N2O", "treat": treat,
    "dose": num(x[33]), "pH": num(x[16]), "CEC": num(x[18]), "SOC": num(x[10]), "clay": num(x[22]),
    "feed": x[25].astype(str).str.lower().str.strip(), "bcC": num(x[26]), "pH_bc": num(x[30]),
    "years": num(x[24]) / 365.0, "field": 1.0, "lat": num(x[5]), "lon": num(x[4]),
    "precip": num(x[8]), "temp": num(x[7]),
    "ck": ck, "lnRR": np.log(t / ck).where((ck > 0) & (t > 0)),
    "v": sdc**2 / (nc * ck**2) + sdt**2 / (nt * t**2),
    "Nrate": np.nan, "HTT": np.nan,
})
n2o = n2o[n2o.lnRR.notna() & (n2o.dose > 0)]
# combined-input treatments (BN, BNPK, ...) share the biochar-only CK in most studies, so their
# contrast includes the input's own effect; keep them only with a matched (different) control.
n_all = len(n2o)
b_cks = n2o[n2o.treat == "B"].assign(c=n2o.ck.round(4)).groupby("study").c.agg(set)
keep = [(tr == "B") or ((s in b_cks.index) and (round(c, 4) not in b_cks[s])) for tr, s, c in zip(n2o.treat, n2o.study, n2o.ck)]
n2o_contam = n2o[~np.array(keep)].copy()
n2o = n2o[np.array(keep)].copy()
print(f"N2O: {n_all} rows; dropped {n_all-len(n2o)} combined-input rows without a matched control "
      f"(their mean lnRR {n2o_contam.lnRR.mean():.3f} vs retained {n2o.lnRR.mean():.3f})")
# identical rows re-entered under different study names
sig = n2o.dose.round(3).astype(str) + "|" + n2o.ck.round(4).astype(str) + "|" + n2o.lnRR.round(4).astype(str)
n0 = len(n2o); n2o = n2o[~sig.duplicated()].copy()
n2o["flooded"] = n2o.crop.str.contains("rice").astype(float)
n2o["fert"] = n2o.treat.str.contains("N").astype(float)   # biochar on an N-fertilised background
n2o["aged"] = (n2o.years > 1.01).astype(float)
n2o["v"] = n2o.v.where(n2o.v > 0)
n2o["v"] = n2o.v.fillna(n2o.v.median())
n2o["v"] = n2o.v.clip(lower=1e-4)                       # guard against SD=0 entries
n2o.to_csv("/home/claude/bc/n2o_obs.csv", index=False)
print(f"N2O rows {n0} -> {len(n2o)} after duplicate removal; studies={n2o.study.nunique()}; "
      f"flooded={n2o.flooded.mean():.2f}; fertilised={n2o.fert.mean():.2f}")
print(f"overall: mean lnRR={n2o.lnRR.mean():.3f}, median={n2o.lnRR.median():.3f}  -> {100*(np.exp(n2o.lnRR.median())-1):.1f}%")

# ---------- 1. within-experiment dose shape ----------
m = experiments(n2o, cols=["study", "crop", "pH", "treat", "years", "lat", "lon", "feed", "bcC"])
print(f"\nwithin-experiment: {len(m)} dose-means, {m.exp.nunique()} experiments, {m.study.nunique()} studies; "
      f"doses {sorted(m.dose.round(1).unique())}")
for wk in ["none", "ivw"]:
    w = weights(m, wk, tau2=0.05)
    Ds, sse = fit_sat(m, w); p, ssep = fit_power(m, w)
    from fitlib import _sse
    sse_lin = _sse(m, m.dose.values, w)[0]
    print(f"  {wk:4s}: Ds={Ds:.2f} (SSE {sse:.3f})  power p={p:.2f} (SSE {ssep:.3f})  linear SSE {sse_lin:.3f}")
bs = boot_studies(m, lambda b: (fit_sat(b, weights(b, "ivw", 0.05))[0], fit_power(b, weights(b, "ivw", 0.05))[0]), n=400)
print(f"  bootstrap 90% CI: Ds [{np.percentile(bs[:,0],5):.2f}, {np.percentile(bs[:,0],95):.2f}], "
      f"p [{np.percentile(bs[:,1],5):.2f}, {np.percentile(bs[:,1],95):.2f}]")
print("  per-experiment dose contrasts (lnRR at higher dose minus lower dose):")
pairs = []
for e, g in m.groupby("exp"):
    g = g.sort_values("dose")
    for i in range(len(g) - 1):
        pairs.append(dict(lo=g.dose.iloc[i], hi=g.dose.iloc[i + 1], diff=g.y.iloc[i + 1] - g.y.iloc[i], study=g.study.iloc[0]))
pairs = pd.DataFrame(pairs)
print(f"    n={len(pairs)}  mean diff={pairs['diff'].mean():.3f}  median={pairs['diff'].median():.3f}  "
      f"share more reduction at higher dose={(pairs['diff']<0).mean():.2f}")
pairs.to_csv("/home/claude/bc/n2o_dose_pairs.csv", index=False)

# ---------- 2. aging: same study, site, dose, crop, treatment & biochar at successive years ----------
key = ["study", "crop", "treat", "dose", "lat", "lon", "feed"]
n2o["akey"] = n2o[key].astype(object).fillna("NA").astype(str).agg("|".join, axis=1)
multi = n2o.groupby("akey").years.transform("nunique") >= 2
A = n2o[multi].copy()
print(f"\naging: {A.akey.nunique()} series observed at >=2 times, {A.study.nunique()} studies, {len(A)} rows")
if len(A):
    A["t_rel"] = A.years - A.groupby("akey").years.transform("min")
    A["y_rel"] = A.lnRR - A.groupby("akey").lnRR.transform(lambda s: s.iloc[np.argmin(A.loc[s.index, "years"].values)])
    print(A.groupby(A.years.round(1)).lnRR.agg(["size", "mean", "median"]).round(3).to_string())
    later = A[A.t_rel > 0]
    print(f"  change in lnRR from first to later time point: mean {later.y_rel.mean():.3f}, median {later.y_rel.median():.3f}, "
          f"n={len(later)}, share weaker (less negative)={(later.y_rel>0).mean():.2f}")
    A.to_csv("/home/claude/bc/n2o_aging_series.csv", index=False)

# ---------- 3. multilevel meta-regression ----------
n2o["logD"] = np.log(n2o.dose)
n2o["pHc"] = n2o.pH - 6.5
res = {}
for lab, cols in [("intercept only", []),
                  ("+ log dose", ["logD"]),
                  ("+ log dose + flooded + fert + aged", ["logD", "flooded", "fert", "aged"]),
                  ("+ log dose + flooded + fert + aged + pH", ["logD", "flooded", "fert", "aged", "pHc"])]:
    sub = n2o.dropna(subset=["pHc"]) if "pHc" in cols else n2o
    r = metareg.fit(sub, "lnRR", "v", cols)
    metareg.show(r, lab); res[lab] = r
# saturating dose term: profile Ds by AIC
print("\nsaturating dose term g(D)=1-exp(-D/Ds), no intercept (zero effect at zero dose):")
best = None
for Ds in [0.5, 1, 2, 3, 5, 8, 12, 20, 40, 80]:
    n2o["g"] = g_sat(n2o.dose, Ds)
    for c in ["flooded", "fert", "aged"]:
        n2o[f"g_{c}"] = n2o.g * n2o[c]
    r = metareg.fit(n2o, "lnRR", "v", ["g", "g_flooded", "g_fert", "g_aged"], intercept=False)
    print(f"  Ds={Ds:5.1f}  AIC={r['aic']:.1f}  Rmax(upland, unfert, yr1)={r['table'].loc['g','est']:.3f}")
    if best is None or r["aic"] < best[1]["aic"]:
        best = (Ds, r)
metareg.show(best[1], f"best saturating model, Ds={best[0]}")
tab = best[1]["table"]
for fl in [0, 1]:
    for fe in [0, 1]:
        for ag in [0, 1]:
            e = tab.loc["g", "est"] + fl * tab.loc["g_flooded", "est"] + fe * tab.loc["g_fert", "est"] + ag * tab.loc["g_aged", "est"]
            print(f"   flooded={fl} fert={fe} aged={ag}: Rmax = {100*(np.exp(e)-1):6.1f}%")
