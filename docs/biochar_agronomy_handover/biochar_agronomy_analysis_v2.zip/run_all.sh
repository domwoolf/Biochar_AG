#!/bin/sh
# Pipeline order (Python 3, pandas, numpy, scipy, scikit-learn, matplotlib). ~15 min.
set -e
python3 harmonise2.py      # clean + deduplicate yield data -> harmonised2.csv
python3 dose2.py           # within-experiment dose shape, 3 weightings -> dose_fits2.csv, dose_two2.csv
python3 shape2.py          # nonparametric dose shape -> step_shape2.csv
python3 n2o.py             # N2O dose, aging, meta-regression -> n2o_obs.csv
python3 persist.py         # persistence of yield response -> persistence.csv
python3 amplitude.py       # amplitude models, grouped CV -> amplitude_obs.csv
python3 amp_cec.py         # pH + CEC subset comparison
python3 regional2.py       # regional dilution -> regional_dilution2.csv
python3 figure2.py         # dose_response_v2.png
