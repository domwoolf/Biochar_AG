import numpy as np, pandas as pd, matplotlib
matplotlib.use("Agg")
import matplotlib.pyplot as plt
import metareg

s = pd.read_csv("/home/claude/bc/step_shape2.csv")
dl = pd.read_csv("/home/claude/bc/regional_dilution2.csv")
n2o = pd.read_csv("/home/claude/bc/n2o_obs.csv")
mid = {"<=2.5": 1.8, "2.5-5": 3.75, "5-10": 7.5, "10-20": 15, "20-40": 30, ">40": 60}
BLUE, ORANGE, GREY = "#2a78d6", "#eb6834", "#6b6a64"
plt.rcParams.update({"font.size": 10, "axes.spines.top": False, "axes.spines.right": False, "axes.edgecolor": "#888",
                     "xtick.color": "#444", "ytick.color": "#444", "axes.labelcolor": "#222"})
fig, ax = plt.subplots(1, 3, figsize=(15.5, 4.9), gridspec_kw=dict(width_ratios=[1.15, 1, 1]))

# a: yield dose shape
a = ax[0]
for k, col, p, lab, off in [("Field pH>=6.5", BLUE, 0.30, "Soil pH ≥ 6.5", 0.93), ("Field pH<6.0", ORANGE, 0.64, "Soil pH < 6.0", 1.07)]:
    g = s[s.subset == k]; x = g.bin.map(mid).values * off
    a.errorbar(x, g.h, yerr=[g.h - g.lo, g.hi - g.h], fmt="o", ms=7, color=col, lw=2, mec="white", mew=1.5, zorder=3)
    D = np.logspace(0, np.log10(80), 100)
    a.plot(D, (D / 15) ** p, color=col, lw=2, alpha=0.55)
    a.text(88, min((80 / 15) ** p, 2.75), f"{lab}\n(power p={p:.2f})", color="#222", va="center", fontsize=9)
a.set_xscale("log"); a.set_xticks([1, 2.5, 5, 10, 20, 40, 100]); a.set_xticklabels(["1", "2.5", "5", "10", "20", "40", "100"])
a.set_xlim(0.8, 450); a.set_ylim(0, 3.6); a.axhline(1, color="#ccc", lw=1, zorder=0)
a.set_xlabel("Biochar dose (Mg ha$^{-1}$, log scale)"); a.set_ylabel("Yield response relative to 10–20 Mg ha$^{-1}$")
a.set_title("a  Yield: within-experiment dose shape", loc="left", fontsize=11)

# b: N2O by dose class (multilevel random-effects mean per class)
b = ax[1]
bins = [0, 5, 10, 20, 40, 100]; labs = ["≤5", "5–10", "10–20", "20–40", ">40"]
n2o["cls"] = pd.cut(n2o.dose, bins, labels=labs)
xs, ys, lo, hi, ns = [], [], [], [], []
for i, L in enumerate(labs):
    sub = n2o[n2o.cls == L]
    if sub.study.nunique() < 3:
        continue
    r = metareg.fit(sub, "lnRR", "v", [])
    est, se = r["table"].est.iloc[0], r["table"].se.iloc[0]
    xs.append(i); ys.append(100 * (np.exp(est) - 1)); lo.append(100 * (np.exp(est - 1.645 * se) - 1)); hi.append(100 * (np.exp(est + 1.645 * se) - 1))
    ns.append(sub.study.nunique())
ys, lo, hi = map(np.array, (ys, lo, hi))
b.errorbar(xs, ys, yerr=[ys - lo, hi - ys], fmt="o", ms=8, color=BLUE, lw=2, mec="white", mew=1.5)
for x_, n_ in zip(xs, ns):
    b.text(x_, -63, f"{n_} studies", ha="center", fontsize=8, color="#555")
b.axhline(0, color="#ccc", lw=1)
r_all = metareg.fit(n2o, "lnRR", "v", [])
m_all = 100 * (np.exp(r_all["table"].est.iloc[0]) - 1)
b.axhline(m_all, color=BLUE, lw=1, ls="--", alpha=0.6)
b.text(len(labs) - 0.6, m_all - 3, f"overall {m_all:.0f}%", fontsize=9, color="#222", ha="right", va="top")
b.set_xticks(range(len(labs))); b.set_xticklabels(labs); b.set_xlim(-0.5, len(labs) - 0.5); b.set_ylim(-67, 45)
b.set_xlabel("Biochar dose (Mg ha$^{-1}$)"); b.set_ylabel("Change in N$_2$O emission (%)")
b.set_title("b  N$_2$O: no dose dependence ≥ 2 Mg ha$^{-1}$", loc="left", fontsize=11)

# c: regional dilution
c = ax[2]
regs = ["Europe", "India", "US", "China"]
for i, rg in enumerate(regs):
    q = dl[(dl.region == rg) & (dl.Dmin == 2.5)]
    cen = q[(q.CI == 1.0) & (q.fit == "all field p=0.50")].mean_ratio.iloc[0]
    lo_ = q[(q.CI == 1.5) & (q.fit == "all field p=0.29 (CI low)")].mean_ratio.iloc[0]
    hi_ = q[(q.CI == 1.0) & (q.fit == "all field p=0.66 (CI high)")].mean_ratio.iloc[0]
    c.plot([lo_, hi_], [i, i], color=GREY, lw=3, solid_capstyle="round", alpha=0.5)
    c.plot(cen, i, "o", ms=9, color=GREY, mec="white", mew=1.5)
    c.text(hi_ + 0.03, i, f"{cen:.2f}", va="center", fontsize=9, color="#222")
c.axvline(1, color="#ccc", lw=1)
c.set_yticks(range(len(regs))); c.set_yticklabels(regs); c.set_xlim(0, 1.15); c.set_ylim(-0.6, len(regs) - 0.4)
c.set_xlabel("Yield value ÷ current linear valuation\n(biochar-weighted; bar: dose-exponent CI × cropping intensity 1–1.5)")
c.set_title("c  Regional dilution of the yield credit", loc="left", fontsize=11)
fig.tight_layout(); fig.savefig("/home/claude/bc/dose_response_v2.png", dpi=170)
