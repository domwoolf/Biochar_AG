"""Regional dilution of the yield credit with the corrected (power-law) dose shape.

f(B) = (B/10)^p for B >= Dmin (response relative to that at 10 Mg/ha); doses below Dmin are not spread,
land is treated in rotating cohorts at Dmin. Benchmark (current linear valuation) = mean over field-trial
doses of f(D)/D, i.e. the per-Mg efficiency a ratio-based meta-estimate implies.
Stock per physical ha = CI * b_h * t; yield gain applies to every harvest.
"""
import numpy as np
import pandas as pd

h = pd.read_csv("/root/.claude/uploads/7dc0de0d-d3f4-577f-ad83-87612b70a8b9/4874f738-biochar_production_histograms_harvested.csv")
fieldD = pd.read_csv("/home/claude/bc/within_exp2.csv").query("field == 1").dose.values
r, T, H = 0.02, 25, 100
t = np.arange(1, H + 1); disc = (1 + r) ** -t
fits = {"all field p=0.50": 0.50, "all field p=0.29 (CI low)": 0.29, "all field p=0.66 (CI high)": 0.66,
        "pH<6.0 p=0.64": 0.64, "pH>=6.5 p=0.30": 0.30}


def f(B, p):
    return np.where(B > 0, (B / 10.0) ** p, 0.0)


def ratio(b, p, Dmin):
    e_bar = np.mean(f(fieldD, p) / fieldD)
    n = max(1, int(np.ceil(Dmin / b)))
    S = np.zeros((n, H))
    for y in range(T):
        S[y % n, y:] += n * b
    pv = (f(S, p).mean(axis=0) * disc).sum()
    lin = e_bar * (np.minimum(t, T) * b * disc).sum()
    return pv / lin


if __name__ == "__main__":
    print("ratio vs supply b (CI=1, Dmin=2.5):")
    for lab, p in fits.items():
        print(f"  {lab:28s}", {b: round(ratio(b, p, 2.5), 2) for b in [0.25, 0.5, 1, 2, 4]})
    rows = []
    for reg, g in h.groupby("region", sort=False):
        for CI in [1.0, 1.5]:
            for Dmin in [1.0, 2.5, 5.0]:
                for lab, p in fits.items():
                    rr = np.array([ratio(CI * b, p, Dmin) for b in g.mean_biochar_Mg_per_ha])
                    rows.append(dict(region=reg, CI=CI, Dmin=Dmin, fit=lab, mean_ratio=(rr * g.share_biochar.values).sum()))
    out = pd.DataFrame(rows)
    out.to_csv("/home/claude/bc/regional_dilution2.csv", index=False)
    pd.set_option("display.width", 250)
    print(out[out.Dmin == 2.5].pivot_table(index=["region", "CI"], columns="fit", values="mean_ratio", sort=False).round(2))
    print("\nsensitivity to Dmin (all field p=0.50):")
    print(out[out.fit == "all field p=0.50"].pivot_table(index=["region", "CI"], columns="Dmin", values="mean_ratio", sort=False).round(2))
