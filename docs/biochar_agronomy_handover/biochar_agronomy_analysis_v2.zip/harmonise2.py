"""Harmonise W16, Xu 2021 and Zhang 2023 yield data (v2).

Changes from v1:
  * biochar identity (feedstock, HTT, %C) kept, so experiments are defined within one biochar
  * Zhang time since application taken from 'Return years of biochar to field'
  * duplicate removal: (a) identical (dose, CK, T) rows re-entered under different study names,
    (b) studies present in more than one dataset (surname + year, coordinates within 1 deg);
    precedence XU21 > ZH23 > W16 for field rows (XU21 carries SD/n and trial duration)
  * sampling variance v kept where SD and n are reported
"""
import re
import unicodedata
import numpy as np
import pandas as pd

D = "/home/claude/bc/"
num = lambda s: pd.to_numeric(s, errors="coerce")


def ascii_low(s):
    return unicodedata.normalize("NFKD", str(s)).encode("ascii", "ignore").decode().lower().strip()


def yrs(s):
    s = str(s).lower()
    y = re.search(r"([\d.]+)\s*year", s); mo = re.search(r"([\d.]+)\s*month", s); dd = re.search(r"([\d.]+)\s*day", s)
    if not (y or mo or dd):
        return np.nan
    return (float(y.group(1)) if y else 0) + (float(mo.group(1)) / 12 if mo else 0) + (float(dd.group(1)) / 365 if dd else 0)


def coord(s):
    s = str(s)
    m = re.findall(r"[\d.]+", s)
    if not m:
        return np.nan
    v = float(m[0]) + (float(m[1]) / 60 if len(m) > 1 and "′" in s or "'" in s and len(m) > 1 else 0)
    return -v if re.search(r"[SW]", s) else v


# ---- W16 ----
w = pd.read_csv(D + "f53f6191-BCYield_data2.csv", encoding="latin1", na_values=["NA"])
m = w.Ref.map(lambda s: re.match(r"\(?\s*([^\s,(]+).*?(\d{4})", ascii_low(s)))
w16 = pd.DataFrame({
    "src": "W16", "study": w.Ref.str.strip(),
    "akey": [f"{x.group(1).strip(' -')}_{x.group(2)}" if x else None for x in m],
    "crop": w.Crop.str.lower().str.strip(), "yieldtype": w.YieldType,
    "dose": w.BC_AppRate, "Nrate": w.Inorg_N_AppRate,
    "pH": w.pH_soil, "CEC": w.CEC, "SOC": w.SOC, "clay": w.Clay * 100,
    "feed": w.Feedstock, "HTT": w.HTT, "bcC": w.BC_percentC * 1000, "pH_bc": w.pH_BC,
    "years": w.Year.astype(float), "years_kind": "year_index",
    "field": 1 - w["pot.trial"], "lat": w.lat, "lon": w.lon,
    "ck": np.nan, "t": np.nan, "lnRR": np.log(w.YieldRatio), "v": np.nan,
})

# ---- XU21 ----
x = pd.read_excel(D + "2f8e6375-Biochar-crop_yield_SOC_GWP.xlsx", "All", header=None).iloc[2:].reset_index(drop=True)
ck, t = num(x[34]), num(x[37])
first = x[0].astype(str).map(ascii_low)
xu = pd.DataFrame({
    "src": "XU21", "study": x[0].astype(str).str.strip() + " " + x[2].astype(str),
    "akey": [f"{(f.split() or [''])[-1]}_{y}" for f, y in zip(first, x[2].astype(str))],
    "crop": x[23].astype(str).str.lower().str.replace(r"[^a-z ]", "", regex=True).str.strip(),
    "yieldtype": "Grain", "dose": num(x[33]), "Nrate": np.nan,
    "pH": num(x[16]), "CEC": num(x[18]), "SOC": num(x[10]), "clay": num(x[22]),
    "feed": x[25].astype(str).str.lower().str.strip(), "HTT": np.nan, "bcC": num(x[26]), "pH_bc": num(x[30]),
    "years": num(x[24]) / 365.0, "years_kind": "duration",
    "field": 1.0, "lat": num(x[5]), "lon": num(x[4]),
    "ck": ck, "t": t, "lnRR": np.log(t / ck).where((ck > 0) & (t > 0)),
    "treat": x[32].astype(str), "precip": num(x[8]), "temp": num(x[7]),
})
sdc, nc, sdt, nt = num(x[35]), num(x[36]), num(x[38]), num(x[39])
xu["v"] = sdc**2 / (nc * ck**2) + sdt**2 / (nt * t**2)

# Treatments combining biochar with another input (BN, BNPK, BM, ...) are mostly compared with the
# same CK as biochar alone (27 of 33 studies with both), i.e. the contrast includes the input's own
# effect. Keep a combined-code row only when its CK is not among the study's biochar-only CKs (a
# matched input-only control); otherwise rebuild the contrast as BX vs X from the Interaction sheet.
xu["ck_r"] = xu.ck.round(3)
b_cks = xu[xu.treat == "B"].groupby("study").ck_r.agg(set)
combo = xu.treat != "B"
matched = [(s in b_cks.index) and (c not in b_cks[s]) for s, c in zip(xu.study, xu.ck_r)]
n_combo = int(combo.sum())
xu = xu[~combo | np.array(matched)].drop(columns="ck_r")
n_combo_kept = int((xu.treat != "B").sum())

it = pd.read_excel(D + "2f8e6375-Biochar-crop_yield_SOC_GWP.xlsx", "Interaction", header=None).iloc[2:].reset_index(drop=True)
I = pd.DataFrame({
    "study": it[0].astype(str).str.strip() + " " + it[2].astype(str), "first": it[0].astype(str).map(ascii_low),
    "year": it[2].astype(str), "lat": num(it[5]), "lon": num(it[4]), "precip": num(it[7]), "temp": num(it[6]),
    "SOC": num(it[8]), "pH": num(it[10]), "clay": num(it[14]),
    "crop": it[15].astype(str).str.lower().str.replace(r"[^a-z ]", "", regex=True).str.strip(),
    "feed": it[16].astype(str).str.lower().str.strip(), "dose": num(it[17]), "bcC": num(it[19]), "pH_bc": num(it[23]),
    "code": it[24].astype(str).str.strip(), "ck": num(it[25]), "t": num(it[28]),
    "vt": num(it[29]) ** 2 / (num(it[30]) * num(it[28]) ** 2),
})
I["grp"] = I[["study", "lat", "crop", "feed", "dose"]].astype(object).fillna("NA").astype(str).agg("|".join, axis=1) + "|" + I.ck.round(3).astype(str)
# trial duration recovered from the matching biochar-only row of the All sheet
dur = xu[xu.treat == "B"].assign(ckr=xu.ck.round(3), tr=xu.t.round(3)).groupby(["study", "dose", "ckr", "tr"]).years.first()
Ib = I[I.code == "B"].assign(ckr=I.ck.round(3), tr=I.t.round(3))
Ib["years"] = [dur.get((s, d, c, t_), np.nan) for s, d, c, t_ in zip(Ib.study, Ib.dose, Ib.ckr, Ib.tr)]
grp_years = Ib.groupby("grp").years.first()
pairs = []
for gk, g in I.groupby("grp"):
    means = g.groupby("code").agg(t=("t", "mean"), vt=("vt", "mean"))
    for code in means.index:
        if code.startswith("B") and len(code) > 1 and code[1:] in means.index:
            tb, tx = means.loc[code, "t"], means.loc[code[1:], "t"]
            if tb > 0 and tx > 0:
                r0 = g.iloc[0]
                pairs.append(dict(src="XU21", study=r0.study, akey=f"{(r0['first'].split() or [''])[-1]}_{r0.year}",
                                  crop=r0.crop, yieldtype="Grain", dose=r0.dose, Nrate=np.nan, pH=r0.pH, CEC=np.nan,
                                  SOC=r0.SOC, clay=r0.clay, feed=r0.feed, HTT=np.nan, bcC=r0.bcC, pH_bc=r0.pH_bc,
                                  years=grp_years.get(gk, np.nan), years_kind="duration", field=1.0,
                                  lat=r0.lat, lon=r0.lon, ck=tx, t=tb, lnRR=np.log(tb / tx),
                                  treat=code + "-vs-" + code[1:], precip=r0.precip, temp=r0.temp,
                                  v=means.loc[code, "vt"] + means.loc[code[1:], "vt"]))
pairs = pd.DataFrame(pairs)
# CEC is not in the Interaction sheet: borrow from the All sheet by study + site
cec = xu.groupby(["study", "lat"]).CEC.first()
pairs["CEC"] = [cec.get((s, la), np.nan) for s, la in zip(pairs.study, pairs.lat)]
# drop BX-vs-X contrasts that duplicate a retained matched-control row from the All sheet
kept_combo = xu[xu.treat != "B"]
sigk = set(zip(kept_combo.study, kept_combo.dose, kept_combo.t.round(3)))
pairs = pairs[[(s, d, round(t_, 3)) not in sigk for s, d, t_ in zip(pairs.study, pairs.dose, pairs.t)]]
xu = pd.concat([xu, pairs], ignore_index=True)

# ---- ZH23 ----
z = pd.read_excel(D + "81961213-1-s2.0-S004896972305917X-mmc1.xlsx", header=None).iloc[3:].reset_index(drop=True)
z[[0, 1, 2, 3, 4, 5, 6]] = z[[0, 1, 2, 3, 4, 5, 6]].ffill()
ty, tc = num(z[53]), num(z[56])
zfirst = z[1].astype(str).map(ascii_low)
zh = pd.DataFrame({
    "src": "ZH23", "study": "Z" + z[0].astype(str) + " " + z[1].astype(str).str.strip() + " " + z[2].astype(str),
    "akey": [f"{(f.split() or [''])[-1]}_{str(y)[:4]}" for f, y in zip(zfirst, z[2])],
    "crop": z[21].astype(str).str.lower().str.strip(), "yieldtype": "Grain",
    "dose": num(z[12]), "Nrate": num(z[19]),
    "pH": num(z[18]), "CEC": np.nan, "SOC": num(z[15]), "clay": np.nan,
    "feed": z[9].astype(str).str.lower().str.strip(), "HTT": num(z[8]), "bcC": np.nan, "pH_bc": num(z[7]),
    "years": z[13].map(yrs), "years_kind": "since_application",
    "field": z[20].astype(str).str.lower().str.contains("field").astype(float),
    "lat": z[5].map(coord), "lon": z[4].map(coord),
    "ck": tc, "t": ty, "lnRR": np.log(ty / tc).where((ty > 0) & (tc > 0)),
})
sdt, nt, sdc, nc = num(z[54]), num(z[55]), num(z[57]), num(z[58])
zh["v"] = sdc**2 / (nc * tc**2) + sdt**2 / (nt * ty**2)
# studies whose control yield does not change with the N level are not N-matched controls
zz = pd.DataFrame({"s": z[0], "N": num(z[19]), "c": tc.round(3)})[ty > 0]
zg = zz.groupby("s").agg(nN=("N", "nunique"), nC=("c", "nunique"))
bad_z = set(zg[(zg.nN > 1) & (zg.nC < zg.nN)].index)
zh = zh[~z[0].isin(bad_z).values]

allx = pd.concat([w16, xu, zh], ignore_index=True)
allx = allx[allx.lnRR.notna() & allx.dose.notna() & (allx.dose > 0)].copy()
n0 = len(allx)

# (a) identical rows re-entered under a different study name (same source, or XU/ZH with raw means)
sig = allx.dose.round(3).astype(str) + "|" + allx.lnRR.round(4).astype(str) + "|" + allx.ck.round(4).astype(str)
dup_a = sig.duplicated() & allx.ck.notna()
# W16 rows have no raw means: duplicate if same dose & lnRR to 3 dp and same crop
sigw = allx.dose.round(3).astype(str) + "|" + allx.lnRR.round(3).astype(str) + "|" + allx.crop
dup_w = (allx.src == "W16") & sigw.duplicated() & (allx.groupby(sigw).study.transform("nunique") > 1)
allx = allx[~(dup_a | dup_w)]
n1 = len(allx)

# (b) same study in several datasets, matched row by row: same first-author surname + year,
#     same dose (within 5%), and site agreeing in latitude OR longitude within 2 deg (one
#     coordinate is mistyped in several entries), or coordinates missing.
drop = pd.Series(False, index=allx.index)
dups = []
pot_fix = set()
# column (lysimeter-type) trials are not field trials
allx.loc[(allx.src == "XU21") & allx.study.isin(
    xu.loc[x[1].astype(str).str.lower().str.contains("column trial"), "study"]), "field"] = 0.0
valid = allx.akey.notna() & ~allx.akey.astype(str).str.startswith("_")
for hi, lo in [("XU21", "ZH23"), ("XU21", "W16"), ("ZH23", "W16")]:
    H = allx[(allx.src == hi) & valid][["akey", "dose", "lat", "lon"]].reset_index().rename(columns={"index": "idx_h"})
    L = allx[(allx.src == lo) & valid][["akey", "dose", "lat", "lon", "field"]].reset_index()
    mm = L.merge(H, on="akey", suffixes=("", "_h"))
    same_dose = (mm.dose - mm.dose_h).abs() <= 0.05 * mm.dose_h
    site = ((mm.lat - mm.lat_h).abs() < 2) | ((mm.lon - mm.lon_h).abs() < 2) | mm[["lat", "lon", "lat_h", "lon_h"]].isna().any(axis=1)
    hit = mm[same_dose & site]
    drop.loc[hit["index"].unique()] = True
    # the authors' own pot/field coding in W16 overrides XU21's blanket 'field' label
    if lo == "W16":
        ph = hit[hit.field == 0]
        pot_fix.update(ph.akey.unique())
        # recode the matched rows, plus same-study rows at the same site (other doses / years)
        for k, g in ph.groupby("akey"):
            same = (allx.src == hi) & (allx.akey == k) & ((allx.lat - g.lat_h.median()).abs() < 0.5)
            allx.loc[same | allx.index.isin(g.idx_h), "field"] = 0.0
    dups += [(hi, lo, k, n) for k, n in hit.groupby("akey")["index"].nunique().items()]
allx = allx[~drop]
allx.to_csv(D + "harmonised2.csv", index=False)
pd.DataFrame(dups, columns=["kept", "dropped", "study", "rows_dropped"]).to_csv(D + "cross_dataset_duplicates.csv", index=False)

if __name__ == "__main__":
    print(f"XU combined-input rows: {n_combo}, kept with matched control: {n_combo_kept}; "
          f"BX-vs-X contrasts added from Interaction sheet: {len(pairs)} (years recovered for {pairs.years.notna().mean():.0%}); "
          f"ZH studies dropped (unmatched N control): {sorted(bad_z)}")
    print(f"rows: {n0} -> {n1} after identical-row removal -> {len(allx)} after cross-dataset removal")
    print(f"cross-dataset duplicate studies: {len(dups)}; XU/ZH studies re-coded as pot from W16: {sorted(pot_fix)}")
    print(allx.groupby("src").agg(n=("lnRR", "size"), studies=("study", "nunique"), field=("field", "mean"),
                                  has_v=("v", lambda s: s.notna().mean())).round(2))
