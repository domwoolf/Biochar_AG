"""Refit yield dose shape on deduplicated data, biochar-specific experiments, three weightings."""
import numpy as np
import pandas as pd
from fitlib import experiments, weights, fit_sat, fit_power, fit_two, tau2_estimate, boot_studies

d = pd.read_csv("/home/claude/bc/harmonised2.csv")
m = experiments(d)
m.to_csv("/home/claude/bc/within_exp2.csv", index=False)
F = m[m.field == 1].reset_index(drop=True)
tau2 = tau2_estimate(F)
print(f"field: {len(F)} dose-means, {F.exp.nunique()} experiments, {F.study.nunique()} studies; tau2={tau2:.4f}, "
      f"median v={np.nanmedian(F.v):.4f}")

subsets = {
    "All field": F,
    "Field pH>=6.5": F[F.pH >= 6.5],
    "Field pH<6.0": F[F.pH < 6.0],
    "Field CEC<=10": F[F.CEC <= 10],
    "Field CEC>10": F[F.CEC > 10],
    "Field first year": F[F.years <= 1.01],
    "Field later years": F[F.years > 1.01],
    "Pot": m[m.field == 0],
}
rows = []
for lab, s in subsets.items():
    s = s.reset_index(drop=True)
    for wk in ["none", "ivw", "study"]:
        w = weights(s, wk, tau2)
        Ds, _ = fit_sat(s, w); p, _ = fit_power(s, w)
        nb = 300 if wk == "ivw" else 0
        if nb:
            bs = boot_studies(s, lambda b: (fit_sat(b, weights(b, wk, tau2))[0], fit_power(b, weights(b, wk, tau2))[0]), n=nb)
            q = np.percentile(bs, [5, 95], axis=0)
        else:
            q = np.full((2, 2), np.nan)
        rows.append(dict(subset=lab, weighting=wk, n=len(s), exps=s.exp.nunique(), studies=s.study.nunique(),
                         Ds=Ds, Ds_lo=q[0, 0], Ds_hi=q[1, 0], p=p, p_lo=q[0, 1], p_hi=q[1, 1]))
        print(f"{lab:18s} {wk:5s} n={len(s):4d} exps={s.exp.nunique():3d} studies={s.study.nunique():3d}  "
              f"Ds={Ds:6.2f} [{q[0,0]:5.2f},{q[1,0]:6.2f}]  p={p:.2f} [{q[0,1]:.2f},{q[1,1]:.2f}]", flush=True)
pd.DataFrame(rows).to_csv("/home/claude/bc/dose_fits2.csv", index=False)

print("\nTwo-component (saturating + linear), ivw:")
two = []
for lab in ["All field", "Field pH>=6.5", "Field pH<6.0"]:
    s = subsets[lab].reset_index(drop=True)
    Ds, c, _ = fit_two(s, weights(s, "ivw", tau2))
    bs = boot_studies(s, lambda b: fit_two(b, weights(b, "ivw", tau2))[:2], n=200)
    q = np.percentile(bs, [5, 95], axis=0)
    two.append(dict(subset=lab, Ds=Ds, Ds_lo=q[0, 0], Ds_hi=q[1, 0], c=c, c_lo=q[0, 1], c_hi=q[1, 1]))
    print(f"  {lab:14s} Ds={Ds:5.2f} [{q[0,0]:.2f},{q[1,0]:.2f}]  c={c:.5f} [{q[0,1]:.5f},{q[1,1]:.5f}] per Mg")
pd.DataFrame(two).to_csv("/home/claude/bc/dose_two2.csv", index=False)
