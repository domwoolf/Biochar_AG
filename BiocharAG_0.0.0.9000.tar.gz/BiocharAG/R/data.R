#' Biochar Permanence Reference Data
#'
#' A dataset containing experimental biochar stability data from Woolf et al. (2021).
#' Used by `calculate_fperm` to predict biochar permanence based on H:C ratios or Pyrolysis Temperature.
#'
#' @format A data frame with 89 rows and 25 variables:
#' \describe{
#'   \item{Reference}{Source of the data}
#'   \item{Feedstock}{Biochar feedstock type}
#'   \item{Pyrolysis_temperature}{Temperature of pyrolysis (Celsius)}
#'   \item{H_to_Corg}{Molar Hydrogen to Organic Carbon ratio}
#'   \item{Temp_of_experiment}{Temperature at which the incubation experiment was conducted}
#'   \item{k1, k2, k3}{Decay rates for the three-pool model}
#'   \item{C1, C2, C3}{Carbon fractions for the three-pool model (Percentages)}
#'   ...
#' }
#' @source Woolf et al. (2021)
#' Biochar Permanence Look-Up Table (Approximate)
#'
#' A list containing pre-calculated Fperm matrices for fast approximation.
#' Generated for Soil Temps (-55 to 40 C), H:C (0-0.7), and PyTemp (350-1000 C).
#'
#' @format A list with components:
#' \describe{
#'   \item{hc_grid}{Matrix of Fperm values (Rows: H:C, Cols: SoilTemp)}
#'   \item{temp_grid}{Matrix of Fperm values (Rows: PyTemp, Cols: SoilTemp)}
#'   \item{soil_temps}{Vector of soil temperatures}
#'   \item{hc_vals}{Vector of H:C ratios}
#'   \item{py_temps}{Vector of pyrolysis temperatures}
#' }
"fperm_lut"
